// lib/mock-data.ts
// Demo data for SautiOS — used in demo mode and development
// All values are realistic for the East African music market

import type { Artist, Song, RoyaltyTransaction, Contract, Event, AirplayDetection } from '@/types/database'

export const DEMO_ARTIST: Artist = {
  id: 'demo-artist-001',
  user_id: null,
  stage_name: 'Justin Mafie',
  legal_name: 'Justin Mafie',
  email: 'justin@creova.ca',
  phone: '+255 754 000 001',
  genre: 'Afrobeats / R&B',
  bio: 'East African diaspora artist bridging Toronto and Dar es Salaam. Founder of CREOVA Music and Sankofa Studio.',
  location_country: 'TZ',
  location_city: 'Dar es Salaam',
  avatar_url: null,
  tier: 'pro',
  cosota_member_id: 'COSOTA-2024-4521',
  nida_number: null,
  wallet_balance_usd: 950.00,
  wallet_balance_tzs: 2_450_000,
  is_active: true,
  created_at: '2024-01-15T08:00:00Z',
  updated_at: '2026-04-01T10:00:00Z',
}

export const DEMO_SONGS: Song[] = [
  { id: 's-001', artist_id: 'demo-artist-001', title: 'Sankofa', isrc: 'TZCRV2024001', genre: 'Afrobeats', release_date: '2024-03-15', status: 'active', total_streams: 312_450, total_royalties_usd: 186.50, duration_seconds: 215, cosota_ref: 'COS-2024-001', master_file_url: null, artwork_url: null, notes: null, created_at: '2024-01-01Z', updated_at: '2026-04-01Z', platforms: ['spotify', 'boomplay', 'apple_music'] },
  { id: 's-002', artist_id: 'demo-artist-001', title: 'Pamoja', isrc: 'TZCRV2024002', genre: 'Afropop', release_date: '2024-06-01', status: 'active', total_streams: 228_100, total_royalties_usd: 142.30, duration_seconds: 198, cosota_ref: 'COS-2024-002', master_file_url: null, artwork_url: null, notes: null, created_at: '2024-01-01Z', updated_at: '2026-04-01Z', platforms: ['spotify', 'audiomack', 'boomplay'] },
  { id: 's-003', artist_id: 'demo-artist-001', title: 'Milioni', isrc: 'TZCRV2024003', genre: 'Bongo Flava', release_date: '2024-08-20', status: 'active', total_streams: 156_770, total_royalties_usd: 98.20, duration_seconds: 231, cosota_ref: 'COS-2024-003', master_file_url: null, artwork_url: null, notes: null, created_at: '2024-01-01Z', updated_at: '2026-04-01Z', platforms: ['spotify', 'youtube', 'boomplay'] },
  { id: 's-004', artist_id: 'demo-artist-001', title: 'Roots & Routes', isrc: 'TZCRV2024004', genre: 'R&B', release_date: '2024-10-05', status: 'active', total_streams: 89_000, total_royalties_usd: 55.80, duration_seconds: 244, cosota_ref: 'COS-2024-004', master_file_url: null, artwork_url: null, notes: null, created_at: '2024-01-01Z', updated_at: '2026-04-01Z', platforms: ['spotify', 'apple_music'] },
  { id: 's-005', artist_id: 'demo-artist-001', title: 'Karibu Nyumbani', isrc: null, genre: 'Bongo Flava', release_date: '2025-01-10', status: 'pending_cosota', total_streams: 41_000, total_royalties_usd: 25.60, duration_seconds: 207, cosota_ref: null, master_file_url: null, artwork_url: null, notes: 'Submitted to COSOTA Jan 15, 2025. Awaiting ISRC assignment.', created_at: '2025-01-01Z', updated_at: '2026-04-01Z', platforms: ['boomplay', 'audiomack'] },
  { id: 's-006', artist_id: 'demo-artist-001', title: 'CREOVA Anthem', isrc: null, genre: 'Afrobeats', release_date: '2025-03-01', status: 'unregistered', total_streams: 20_000, total_royalties_usd: 0, duration_seconds: 180, cosota_ref: null, master_file_url: null, artwork_url: null, notes: 'Not yet registered with COSOTA. Missing royalties on YouTube.', created_at: '2025-03-01Z', updated_at: '2026-04-01Z', platforms: ['youtube'] },
]

export const DEMO_TRANSACTIONS: RoyaltyTransaction[] = [
  { id: 'tx-001', artist_id: 'demo-artist-001', song_id: null, transaction_type: 'streaming', platform: 'Spotify', amount_usd: 119.20, amount_tzs: 307_480, fee_usd: 2.38, net_usd: 116.82, status: 'completed', reference: 'SPT-2026-MAR', description: 'Spotify streaming royalties — March 2026', period_start: '2026-03-01', period_end: '2026-03-31', created_at: '2026-04-05T09:00:00Z' },
  { id: 'tx-002', artist_id: 'demo-artist-001', song_id: null, transaction_type: 'streaming', platform: 'Boomplay', amount_usd: 42.30, amount_tzs: 109_134, fee_usd: 0.85, net_usd: 41.45, status: 'completed', reference: 'BPL-2026-MAR', description: 'Boomplay streaming royalties — March 2026', period_start: '2026-03-01', period_end: '2026-03-31', created_at: '2026-04-03T08:00:00Z' },
  { id: 'tx-003', artist_id: 'demo-artist-001', song_id: null, transaction_type: 'withdrawal', platform: 'M-Pesa', amount_usd: -200.00, amount_tzs: -516_000, fee_usd: 3.00, net_usd: -203.00, status: 'completed', reference: 'MPESA-TZ-88421', description: 'Withdrawal to M-Pesa +255 754 000 001', period_start: null, period_end: null, created_at: '2026-02-20T14:22:00Z' },
  { id: 'tx-004', artist_id: 'demo-artist-001', song_id: null, transaction_type: 'performance_fee', platform: null, amount_usd: 1500.00, amount_tzs: 3_870_000, fee_usd: 45.00, net_usd: 1455.00, status: 'completed', reference: 'SZB-2025-PERF', description: 'Sauti za Busara Festival performance fee', period_start: '2025-02-10', period_end: '2025-02-10', created_at: '2025-02-12T10:00:00Z' },
  { id: 'tx-005', artist_id: 'demo-artist-001', song_id: null, transaction_type: 'streaming', platform: 'Apple Music', amount_usd: 98.40, amount_tzs: 253_872, fee_usd: 1.97, net_usd: 96.43, status: 'completed', reference: 'APL-2026-FEB', description: 'Apple Music royalties — February 2026', period_start: '2026-02-01', period_end: '2026-02-28', created_at: '2026-03-10T09:00:00Z' },
]

export const DEMO_CONTRACTS: Contract[] = [
  { id: 'c-001', artist_id: 'demo-artist-001', contract_type: 'performance', title: 'Sauti za Busara Festival', counterparty: 'Sauti za Busara Foundation', counterparty_email: 'bookings@sautizabusara.com', value_usd: 1500, value_tzs: 3_870_000, currency: 'USD', status: 'completed', signed_date: '2025-01-15', start_date: '2025-02-10', end_date: '2025-02-10', terms_text: 'One headline performance. 2 x 45 minute sets. Full production provided by venue.', file_url: null, notes: 'Completed. Payment received Feb 12.', created_at: '2025-01-10Z', updated_at: '2025-02-12Z' },
  { id: 'c-002', artist_id: 'demo-artist-001', contract_type: 'brand_deal', title: 'Safaricom Social Campaign', counterparty: 'Safaricom PLC', counterparty_email: 'partnerships@safaricom.co.ke', value_usd: 3000, value_tzs: 7_740_000, currency: 'USD', status: 'pending_signature', signed_date: null, start_date: '2025-05-01', end_date: '2025-07-31', terms_text: 'Create 6 branded social media posts and 2 short video clips featuring Safaricom data bundles. Usage rights: digital only, EAC region.', file_url: null, notes: 'Awaiting Safaricom legal review. Sent contract Apr 1.', created_at: '2025-03-20Z', updated_at: '2025-04-01Z' },
  { id: 'c-003', artist_id: 'demo-artist-001', contract_type: 'sync_license', title: 'Documentary Score — "The Journey"', counterparty: 'NTV Tanzania', counterparty_email: 'production@ntv.co.tz', value_usd: 800, value_tzs: 2_064_000, currency: 'USD', status: 'completed', signed_date: '2024-11-20', start_date: '2024-12-01', end_date: '2025-11-30', terms_text: 'Non-exclusive sync license for "Sankofa" in documentary series "The Journey". 3 episodes, Tanzania broadcast rights only.', file_url: null, notes: null, created_at: '2024-11-15Z', updated_at: '2024-12-01Z' },
  { id: 'c-004', artist_id: 'demo-artist-001', contract_type: 'performance', title: 'Karibu Festival Zanzibar', counterparty: 'Zanzibar Cultural Festival', counterparty_email: 'artists@karibu-festival.com', value_usd: 2000, value_tzs: 5_160_000, currency: 'USD', status: 'draft', signed_date: null, start_date: '2025-07-05', end_date: '2025-07-05', terms_text: null, file_url: null, notes: 'Offer received. Need to negotiate rider and technical requirements.', created_at: '2025-04-10Z', updated_at: '2025-04-10Z' },
]

export const DEMO_EVENTS: Event[] = [
  { id: 'e-001', artist_id: 'demo-artist-001', name: 'CREOVA LIVE — Dar es Salaam', description: 'An intimate evening of Afrobeats, Bongo Flava, and stories from the diaspora. Featuring Justin Mafie and special guests.', venue: 'Mlimani City Amphitheatre', city: 'Dar es Salaam', country: 'TZ', event_date: '2025-06-14T19:00:00Z', doors_open: '18:00', capacity: 500, tickets_sold: 312, ticket_price_tzs: 15000, ticket_price_usd: 6, status: 'on_sale', poster_url: null, total_revenue_tzs: 4_680_000, platform_fee_pct: 3.0, created_at: '2025-03-01Z', updated_at: '2026-04-01Z' },
  { id: 'e-002', artist_id: 'demo-artist-001', name: 'Sankofa Sessions — Toronto', description: 'An evening of East African diaspora music in Toronto. Celebrating the sounds of home.', venue: 'Drake Hotel Underground', city: 'Toronto', country: 'CA', event_date: '2025-07-22T21:00:00Z', doors_open: '20:00', capacity: 200, tickets_sold: 89, ticket_price_tzs: 0, ticket_price_usd: 35, status: 'on_sale', poster_url: null, total_revenue_tzs: 311_500, platform_fee_pct: 3.0, created_at: '2025-03-15Z', updated_at: '2026-04-01Z' },
]

export const DEMO_AIRPLAY: AirplayDetection[] = [
  { id: 'ap-001', song_id: 's-001', artist_id: 'demo-artist-001', station_name: 'Radio Tanzania Dar es Salaam', station_type: 'radio', country: 'TZ', detected_at: '2026-04-15T14:30:00Z', duration_seconds: 215, claimed: false, cosota_claim_ref: null, created_at: '2026-04-15Z' },
  { id: 'ap-002', song_id: 's-002', artist_id: 'demo-artist-001', station_name: 'ITV Tanzania', station_type: 'tv', country: 'TZ', detected_at: '2026-04-14T20:15:00Z', duration_seconds: 198, claimed: false, cosota_claim_ref: null, created_at: '2026-04-14Z' },
  { id: 'ap-003', song_id: 's-001', artist_id: 'demo-artist-001', station_name: 'Kiss FM Tanzania', station_type: 'radio', country: 'TZ', detected_at: '2026-04-13T09:00:00Z', duration_seconds: 215, claimed: false, cosota_claim_ref: null, created_at: '2026-04-13Z' },
  { id: 'ap-004', song_id: 's-003', artist_id: 'demo-artist-001', station_name: 'Capital FM Kenya', station_type: 'radio', country: 'KE', detected_at: '2026-04-12T16:45:00Z', duration_seconds: 231, claimed: true, cosota_claim_ref: 'CLM-2026-0041', created_at: '2026-04-12Z' },
]

export const DEMO_MONTHLY_EARNINGS = [
  { month: 'Oct', earned: 42, streams: 68_000 },
  { month: 'Nov', earned: 68, streams: 95_000 },
  { month: 'Dec', earned: 91, streams: 132_000 },
  { month: 'Jan', earned: 78, streams: 112_000 },
  { month: 'Feb', earned: 110, streams: 155_000 },
  { month: 'Mar', earned: 119, streams: 168_000 },
]

export const DEMO_PLATFORM_EARNINGS = [
  { name: 'Spotify', amount: 245.30, color: '#1DB954', streams: 520_000 },
  { name: 'Boomplay', amount: 98.50, color: '#FF6B35', streams: 180_000 },
  { name: 'Apple Music', amount: 87.20, color: '#FA243C', streams: 95_000 },
  { name: 'Audiomack', amount: 52.40, color: '#F9A825', streams: 40_000 },
  { name: 'YouTube', amount: 25.00, color: '#FF0000', streams: 12_320 },
]

export const PENDING_COSOTA = 890.00
export const UNCOLLECTED_RADIO = 2_200.00
export const TOTAL_COLLECTED = DEMO_PLATFORM_EARNINGS.reduce((s, p) => s + p.amount, 0)
