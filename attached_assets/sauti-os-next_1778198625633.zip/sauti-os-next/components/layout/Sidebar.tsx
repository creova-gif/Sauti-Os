'use client'
// components/layout/Sidebar.tsx
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { DEMO_ARTIST } from '@/lib/mock-data'

const NAV_ITEMS = [
  { href: '/dashboard', icon: '⬡', label: 'Dashboard' },
  { href: '/catalog', icon: '🎵', label: 'My Catalog' },
  { href: '/royalties', icon: '💰', label: 'Royalties' },
  { href: '/contracts', icon: '📋', label: 'Contracts' },
  { href: '/events', icon: '🎤', label: 'Events' },
]

export default function Sidebar() {
  const pathname = usePathname()

  return (
    <aside className="fixed top-0 left-0 bottom-0 w-60 bg-surface border-r border-border flex flex-col z-50">
      {/* Logo */}
      <div className="px-5 py-6 border-b border-border">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-gold rounded-lg flex items-center justify-center text-base shrink-0">🎵</div>
          <div>
            <div className="font-display font-extrabold text-base leading-none">SautiOS</div>
            <div className="text-[9px] text-gold font-bold tracking-[2px] uppercase mt-0.5">by CREOVA</div>
          </div>
        </div>
      </div>

      {/* Artist card */}
      <div className="px-4 py-4 border-b border-border">
        <div className="flex items-center gap-2.5 mb-3">
          <div className="w-10 h-10 rounded-full shrink-0 bg-gradient-to-br from-gold to-teal flex items-center justify-center font-display font-extrabold text-sm text-black">
            JM
          </div>
          <div className="min-w-0">
            <div className="font-semibold text-[13px] text-white truncate">{DEMO_ARTIST.stage_name}</div>
            <div className="text-[11px] text-dim mt-0.5">{DEMO_ARTIST.genre}</div>
          </div>
        </div>
        <div className="bg-gold/8 border border-gold/15 rounded-lg px-3 py-2.5">
          <div className="text-[10px] text-gold font-bold tracking-[1px] uppercase mb-1">Royalty Wallet</div>
          <div className="font-display font-extrabold text-white text-lg leading-none">${DEMO_ARTIST.wallet_balance_usd.toLocaleString()}</div>
          <div className="text-[11px] text-dim mt-0.5">TZS {DEMO_ARTIST.wallet_balance_tzs.toLocaleString()}</div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 py-3 px-2">
        {NAV_ITEMS.map(item => {
          const active = pathname.startsWith(item.href)
          return (
            <Link key={item.href} href={item.href}
              className={`flex items-center gap-3 w-full px-3.5 py-2.5 rounded-lg text-[13px] font-medium mb-0.5 transition-all
                ${active
                  ? 'bg-gold/10 text-gold border-l-2 border-gold pl-[12px]'
                  : 'text-muted hover:text-white hover:bg-surface-2 border-l-2 border-transparent pl-[12px]'
                }`}
            >
              <span className="text-base">{item.icon}</span>
              {item.label}
            </Link>
          )
        })}
      </nav>

      {/* Footer */}
      <div className="p-3 border-t border-border space-y-2">
        <div className="px-3 py-2.5 bg-teal/6 border border-teal/15 rounded-lg">
          <div className="text-[10px] text-teal font-bold tracking-[1px] uppercase">Pro Plan</div>
          <div className="text-[11px] text-dim mt-0.5">2% royalty fee · All features</div>
        </div>
        <Link href="/auth/logout"
          className="flex items-center gap-2 w-full px-3 py-2 text-[13px] text-dim hover:text-white rounded-lg transition-colors">
          ← Sign Out
        </Link>
      </div>
    </aside>
  )
}
