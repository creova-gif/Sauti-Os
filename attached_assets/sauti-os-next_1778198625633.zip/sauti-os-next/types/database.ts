// types/database.ts
export type Json = string | number | boolean | null | { [key: string]: Json } | Json[]

export type ArtistTier = 'free' | 'pro' | 'label'
export type SongStatus = 'unregistered' | 'pending_cosota' | 'active' | 'suspended'
export type ContractType = 'performance' | 'brand_deal' | 'sync_license' | 'management' | 'distribution'
export type ContractStatus = 'draft' | 'pending_signature' | 'active' | 'completed' | 'cancelled' | 'disputed'
export type EventStatus = 'draft' | 'on_sale' | 'sold_out' | 'completed' | 'cancelled'
export type PayoutStatus = 'pending' | 'processing' | 'completed' | 'failed'
export type Platform = 'spotify' | 'boomplay' | 'apple_music' | 'audiomack' | 'youtube' | 'deezer' | 'tidal' | 'soundcloud'

export interface Artist {
  id: string
  user_id: string | null
  stage_name: string
  legal_name: string | null
  email: string
  phone: string | null
  genre: string | null
  bio: string | null
  location_country: string
  location_city: string | null
  avatar_url: string | null
  tier: ArtistTier
  cosota_member_id: string | null
  nida_number: string | null
  wallet_balance_usd: number
  wallet_balance_tzs: number
  is_active: boolean
  created_at: string
  updated_at: string
}

export interface Song {
  id: string
  artist_id: string
  title: string
  isrc: string | null
  genre: string | null
  release_date: string | null
  duration_seconds: number | null
  status: SongStatus
  cosota_ref: string | null
  master_file_url: string | null
  artwork_url: string | null
  total_streams: number
  total_royalties_usd: number
  notes: string | null
  created_at: string
  updated_at: string
  // joined
  platforms?: Platform[]
}

export interface StreamReport {
  id: string
  song_id: string
  artist_id: string
  platform: Platform
  report_month: string
  streams: number
  royalties_usd: number
  territory: string | null
  created_at: string
}

export interface RoyaltyTransaction {
  id: string
  artist_id: string
  song_id: string | null
  transaction_type: string
  platform: string | null
  amount_usd: number
  amount_tzs: number | null
  fee_usd: number
  net_usd: number
  status: PayoutStatus
  reference: string | null
  description: string | null
  period_start: string | null
  period_end: string | null
  created_at: string
}

export interface Contract {
  id: string
  artist_id: string
  contract_type: ContractType
  title: string
  counterparty: string
  counterparty_email: string | null
  value_usd: number | null
  value_tzs: number | null
  currency: string
  status: ContractStatus
  signed_date: string | null
  start_date: string | null
  end_date: string | null
  terms_text: string | null
  file_url: string | null
  notes: string | null
  created_at: string
  updated_at: string
}

export interface ContractMilestone {
  id: string
  contract_id: string
  description: string
  amount_usd: number
  due_date: string
  paid_at: string | null
  status: string
  created_at: string
}

export interface Event {
  id: string
  artist_id: string
  name: string
  description: string | null
  venue: string | null
  city: string | null
  country: string
  event_date: string
  doors_open: string | null
  capacity: number
  tickets_sold: number
  ticket_price_tzs: number | null
  ticket_price_usd: number | null
  status: EventStatus
  poster_url: string | null
  total_revenue_tzs: number
  platform_fee_pct: number
  created_at: string
  updated_at: string
}

export interface TicketPurchase {
  id: string
  event_id: string
  buyer_name: string
  buyer_phone: string
  buyer_email: string | null
  quantity: number
  total_tzs: number
  payment_method: string
  mpesa_ref: string | null
  ticket_code: string
  checked_in: boolean
  created_at: string
}

export interface AirplayDetection {
  id: string
  song_id: string
  artist_id: string
  station_name: string
  station_type: string
  country: string
  detected_at: string
  duration_seconds: number | null
  claimed: boolean
  cosota_claim_ref: string | null
  created_at: string
}

// Typed Supabase DB interface
export interface Database {
  public: {
    Tables: {
      sauti_artists: { Row: Artist; Insert: Partial<Artist>; Update: Partial<Artist> }
      sauti_songs: { Row: Song; Insert: Partial<Song>; Update: Partial<Song> }
      sauti_stream_reports: { Row: StreamReport; Insert: Partial<StreamReport>; Update: Partial<StreamReport> }
      sauti_royalty_transactions: { Row: RoyaltyTransaction; Insert: Partial<RoyaltyTransaction>; Update: Partial<RoyaltyTransaction> }
      sauti_contracts: { Row: Contract; Insert: Partial<Contract>; Update: Partial<Contract> }
      sauti_contract_milestones: { Row: ContractMilestone; Insert: Partial<ContractMilestone>; Update: Partial<ContractMilestone> }
      sauti_events: { Row: Event; Insert: Partial<Event>; Update: Partial<Event> }
      sauti_ticket_purchases: { Row: TicketPurchase; Insert: Partial<TicketPurchase>; Update: Partial<TicketPurchase> }
      sauti_airplay_detections: { Row: AirplayDetection; Insert: Partial<AirplayDetection>; Update: Partial<AirplayDetection> }
    }
  }
}
