'use client'
// app/catalog/page.tsx
import { useState } from 'react'
import { DEMO_SONGS } from '@/lib/mock-data'
import type { Song, SongStatus, Platform } from '@/types/database'

const PLATFORM_COLORS: Record<string, string> = {
  spotify: '#1DB954', boomplay: '#FF6B35', apple_music: '#FA243C',
  audiomack: '#F9A825', youtube: '#FF0000', deezer: '#00C7F2',
  tidal: '#ffffff', soundcloud: '#FF5500',
}
const PLATFORM_ICONS: Record<string, string> = {
  spotify: '🟢', boomplay: '🟠', apple_music: '🔴', audiomack: '🟡',
  youtube: '▶️', deezer: '🔵', tidal: '⬡', soundcloud: '🟧',
}
const ALL_PLATFORMS: Platform[] = ['spotify', 'boomplay', 'apple_music', 'audiomack', 'youtube', 'deezer', 'tidal', 'soundcloud']

const STATUS_CONFIG: Record<SongStatus, { badge: string; label: string }> = {
  active:          { badge: 'badge-active',  label: '● Registered' },
  pending_cosota:  { badge: 'badge-pending', label: '◌ Pending COSOTA' },
  unregistered:    { badge: 'badge-error',   label: '✕ Unregistered' },
  suspended:       { badge: 'badge-error',   label: '! Suspended' },
}

function generateISRC(index: number): string {
  const year = new Date().getFullYear().toString().slice(2)
  const seq = String(index + 1).padStart(5, '0')
  return `TZCRV${year}${seq}`
}

export default function CatalogPage() {
  const [songs, setSongs] = useState<Song[]>(DEMO_SONGS)
  const [filter, setFilter] = useState<string>('all')
  const [search, setSearch] = useState('')
  const [showAdd, setShowAdd] = useState(false)
  const [selected, setSelected] = useState<Song | null>(null)
  const [saved, setSaved] = useState(false)
  const [form, setForm] = useState({
    title: '', genre: '', release_date: '',
    platforms: [] as Platform[], notes: '',
  })

  const filtered = songs.filter(s => {
    const matchFilter = filter === 'all' || s.status === filter
    const matchSearch = !search || s.title.toLowerCase().includes(search.toLowerCase()) || s.genre?.toLowerCase().includes(search.toLowerCase())
    return matchFilter && matchSearch
  })

  const totalStreams = songs.reduce((s, song) => s + song.total_streams, 0)
  const totalRoyalties = songs.reduce((s, song) => s + song.total_royalties_usd, 0)
  const registered = songs.filter(s => s.status === 'active').length
  const unregistered = songs.filter(s => s.status === 'unregistered').length

  const handleAdd = () => {
    if (!form.title.trim()) return
    const newISRC = form.platforms.length > 0 ? null : null
    const newSong: Song = {
      id: `s-${Date.now()}`,
      artist_id: 'demo-artist-001',
      title: form.title,
      isrc: null,
      genre: form.genre || 'Unknown',
      release_date: form.release_date || new Date().toISOString().split('T')[0],
      duration_seconds: null,
      status: 'unregistered',
      cosota_ref: null,
      master_file_url: null,
      artwork_url: null,
      total_streams: 0,
      total_royalties_usd: 0,
      notes: form.notes || null,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      platforms: form.platforms,
    }
    setSongs(prev => [newSong, ...prev])
    setForm({ title: '', genre: '', release_date: '', platforms: [], notes: '' })
    setShowAdd(false)
    setSaved(true)
    setTimeout(() => setSaved(false), 4000)
  }

  const handleRegister = (songId: string) => {
    setSongs(prev => prev.map((s, i) =>
      s.id === songId
        ? { ...s, status: 'pending_cosota' as SongStatus, isrc: null, cosota_ref: `COS-PEND-${Date.now()}` }
        : s
    ))
    setSelected(null)
  }

  const togglePlatform = (p: Platform) => {
    setForm(f => ({
      ...f,
      platforms: f.platforms.includes(p) ? f.platforms.filter(x => x !== p) : [...f.platforms, p]
    }))
  }

  return (
    <div className="p-10 max-w-[1100px] animate-fade-up">
      {/* Header */}
      <div className="flex justify-between items-start mb-8">
        <div>
          <h1 className="font-display text-4xl font-extrabold tracking-tight mb-1.5">My Catalog</h1>
          <p className="text-muted text-sm">
            {songs.length} songs · {registered} with ISRC · {unregistered} unregistered
          </p>
        </div>
        <button className="btn-primary" onClick={() => setShowAdd(true)}>+ Register Song</button>
      </div>

      {/* Success banner */}
      {saved && (
        <div className="flex items-center gap-3 bg-teal/10 border border-teal/25 rounded-xl px-5 py-3.5 mb-6 text-teal text-sm font-semibold">
          <span>✓</span>
          Song added to catalog. Submit to COSOTA to get an ISRC code and start collecting royalties.
          <button className="ml-auto btn-ghost text-xs py-1.5 px-3">Submit to COSOTA</button>
        </div>
      )}

      {/* Stats row */}
      <div className="grid grid-cols-4 gap-4 mb-7">
        {[
          { label: 'Total Songs', value: songs.length, accent: '' },
          { label: 'Total Streams', value: `${(totalStreams / 1000).toFixed(0)}K`, accent: 'teal' },
          { label: 'Total Royalties', value: `$${totalRoyalties.toFixed(0)}`, accent: '' },
          { label: 'Unregistered', value: unregistered, accent: 'danger' },
        ].map(s => (
          <div key={s.label} className={`stat-card ${s.accent}`}>
            <p className="text-[11px] text-dim font-bold tracking-[1px] uppercase mb-3">{s.label}</p>
            <p className="font-display text-3xl font-extrabold text-white">{s.value}</p>
          </div>
        ))}
      </div>

      {/* COSOTA warning */}
      {unregistered > 0 && (
        <div className="flex items-start gap-4 bg-gold/6 border border-gold/20 rounded-xl px-5 py-4 mb-6">
          <span className="text-xl shrink-0 mt-0.5">💡</span>
          <div>
            <p className="font-semibold text-gold text-sm mb-0.5">{unregistered} song{unregistered > 1 ? 's' : ''} not registered with COSOTA</p>
            <p className="text-muted text-[13px]">Unregistered songs earn no radio airplay royalties in Tanzania. COSOTA registration takes ~14 days and generates a permanent ISRC code.</p>
          </div>
          <button className="btn-primary shrink-0 text-xs">Register All</button>
        </div>
      )}

      {/* Filters + search */}
      <div className="flex items-center gap-3 mb-5">
        <div className="flex gap-1 bg-surface border border-border rounded-xl p-1">
          {[['all','All'],['active','Registered'],['pending_cosota','Pending'],['unregistered','Unregistered']].map(([val, label]) => (
            <button key={val} onClick={() => setFilter(val)}
              className={`px-4 py-2 rounded-lg text-[13px] font-semibold transition-all
                ${filter === val ? 'bg-gold text-black' : 'text-muted hover:text-white'}`}>
              {label}
            </button>
          ))}
        </div>
        <input
          className="input flex-1 max-w-xs"
          placeholder="Search songs..."
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
      </div>

      {/* Catalog table */}
      <div className="card p-0 overflow-hidden mb-5">
        <table className="w-full border-collapse">
          <thead>
            <tr className="border-b border-border bg-surface-2/50">
              {['#','Song','ISRC','Genre','Platforms','Streams','Royalties','Status',''].map(h => (
                <th key={h} className="px-5 py-3.5 text-left text-[10px] text-dim font-bold tracking-[1.5px] uppercase whitespace-nowrap">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((song, i) => (
              <tr key={song.id}
                className="border-b border-border last:border-0 hover:bg-surface-2/40 transition-colors cursor-pointer"
                onClick={() => setSelected(song)}>
                <td className="px-5 py-4 font-display font-extrabold text-dim text-sm w-10">{i + 1}</td>
                <td className="px-5 py-4">
                  <p className="font-semibold text-[14px] text-white">{song.title}</p>
                  <p className="text-[11px] text-dim mt-0.5">
                    {song.release_date ? new Date(song.release_date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : '—'}
                  </p>
                </td>
                <td className="px-5 py-4">
                  {song.isrc
                    ? <span className="font-mono-custom text-[12px] text-teal bg-teal/8 border border-teal/20 rounded px-2 py-0.5">{song.isrc}</span>
                    : <span className="text-[12px] text-dim italic">Not assigned</span>
                  }
                </td>
                <td className="px-5 py-4 text-[13px] text-muted whitespace-nowrap">{song.genre ?? '—'}</td>
                <td className="px-5 py-4">
                  <div className="flex gap-1">
                    {(song.platforms ?? []).map(p => (
                      <span key={p} title={p.replace('_',' ')} className="text-[14px]">{PLATFORM_ICONS[p] ?? '●'}</span>
                    ))}
                    {(!song.platforms || song.platforms.length === 0) && <span className="text-dim text-xs">—</span>}
                  </div>
                </td>
                <td className="px-5 py-4 font-display font-bold text-[15px] text-white whitespace-nowrap">{song.total_streams.toLocaleString()}</td>
                <td className="px-5 py-4 font-display font-bold text-[15px] text-gold whitespace-nowrap">${song.total_royalties_usd.toFixed(2)}</td>
                <td className="px-5 py-4">
                  <span className={STATUS_CONFIG[song.status].badge}>{STATUS_CONFIG[song.status].label}</span>
                </td>
                <td className="px-5 py-4">
                  <button className="text-dim hover:text-white text-xs transition-colors" onClick={e => { e.stopPropagation(); setSelected(song) }}>
                    Details →
                  </button>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr>
                <td colSpan={9} className="text-center py-16 text-dim">
                  <p className="text-3xl mb-3">🎵</p>
                  <p className="text-muted font-semibold">No songs found</p>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Song detail drawer */}
      {selected && (
        <div className="fixed inset-0 bg-black/70 z-50 flex justify-end" onClick={() => setSelected(null)}>
          <div className="w-[460px] bg-surface border-l border-border h-full overflow-y-auto p-8" onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-start mb-6">
              <div>
                <span className={STATUS_CONFIG[selected.status].badge}>{STATUS_CONFIG[selected.status].label}</span>
                <h2 className="font-display font-extrabold text-xl mt-2">{selected.title}</h2>
                <p className="text-muted text-sm">{selected.genre}</p>
              </div>
              <button onClick={() => setSelected(null)} className="text-dim hover:text-white text-xl leading-none">✕</button>
            </div>

            <div className="space-y-5">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-[10px] text-dim font-bold uppercase tracking-wider mb-1">ISRC Code</p>
                  <p className="text-sm font-mono-custom text-teal">{selected.isrc ?? 'Not assigned'}</p>
                </div>
                <div>
                  <p className="text-[10px] text-dim font-bold uppercase tracking-wider mb-1">COSOTA Ref</p>
                  <p className="text-sm text-white">{selected.cosota_ref ?? 'Not submitted'}</p>
                </div>
                <div>
                  <p className="text-[10px] text-dim font-bold uppercase tracking-wider mb-1">Release Date</p>
                  <p className="text-sm text-white">{selected.release_date ? new Date(selected.release_date).toLocaleDateString() : '—'}</p>
                </div>
                <div>
                  <p className="text-[10px] text-dim font-bold uppercase tracking-wider mb-1">Duration</p>
                  <p className="text-sm text-white">{selected.duration_seconds ? `${Math.floor(selected.duration_seconds/60)}:${String(selected.duration_seconds%60).padStart(2,'0')}` : '—'}</p>
                </div>
              </div>

              <div>
                <p className="text-[10px] text-dim font-bold uppercase tracking-wider mb-2">Platforms</p>
                <div className="flex flex-wrap gap-2">
                  {(selected.platforms ?? []).map(p => (
                    <span key={p} className="flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-lg border border-border text-muted">
                      {PLATFORM_ICONS[p]} {p.replace('_', ' ')}
                    </span>
                  ))}
                  {(!selected.platforms || selected.platforms.length === 0) && <p className="text-dim text-sm">Not on any platform yet</p>}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 p-4 bg-bg-2 rounded-xl border border-border">
                <div>
                  <p className="text-[10px] text-dim font-bold uppercase tracking-wider mb-1">Total Streams</p>
                  <p className="font-display font-extrabold text-xl text-white">{selected.total_streams.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-[10px] text-dim font-bold uppercase tracking-wider mb-1">Royalties Earned</p>
                  <p className="font-display font-extrabold text-xl text-gold">${selected.total_royalties_usd.toFixed(2)}</p>
                </div>
              </div>

              {selected.notes && (
                <div>
                  <p className="text-[10px] text-dim font-bold uppercase tracking-wider mb-2">Notes</p>
                  <p className="text-[13px] text-muted bg-bg-2 rounded-lg p-3">{selected.notes}</p>
                </div>
              )}
            </div>

            <div className="mt-8 space-y-3">
              {selected.status === 'unregistered' && (
                <button className="btn-primary w-full justify-center py-3" onClick={() => handleRegister(selected.id)}>
                  Submit to COSOTA →
                </button>
              )}
              {selected.status === 'pending_cosota' && (
                <div className="w-full bg-gold/8 border border-gold/20 rounded-lg p-4 text-center">
                  <p className="text-gold font-semibold text-sm">◌ Pending COSOTA Review</p>
                  <p className="text-dim text-xs mt-1">ISRC will be assigned within 14 business days</p>
                </div>
              )}
              <button className="btn-ghost w-full justify-center py-3">Edit Song Details</button>
            </div>
          </div>
        </div>
      )}

      {/* Add song modal */}
      {showAdd && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4">
          <div className="bg-surface border border-border rounded-2xl p-10 w-[520px] max-h-[90vh] overflow-y-auto">
            <h2 className="font-display font-extrabold text-2xl mb-1.5">Register New Song</h2>
            <p className="text-muted text-[13px] mb-7">
              Adding your song begins the COSOTA registration process. An ISRC code will be assigned within 14 days.
            </p>

            <div className="space-y-5">
              {[
                { label: 'Song Title *', key: 'title', type: 'text', placeholder: 'e.g. Sankofa' },
                { label: 'Genre', key: 'genre', type: 'text', placeholder: 'e.g. Afrobeats, Bongo Flava, R&B' },
                { label: 'Release Date', key: 'release_date', type: 'date', placeholder: '' },
              ].map(field => (
                <div key={field.key}>
                  <label className="label">{field.label}</label>
                  <input className="input" type={field.type} placeholder={field.placeholder}
                    value={(form as any)[field.key]}
                    onChange={e => setForm(f => ({ ...f, [field.key]: e.target.value }))} />
                </div>
              ))}

              <div>
                <label className="label">Platforms</label>
                <div className="grid grid-cols-4 gap-2">
                  {ALL_PLATFORMS.map(p => {
                    const on = form.platforms.includes(p)
                    return (
                      <button key={p} type="button" onClick={() => togglePlatform(p)}
                        className={`py-2 px-2 rounded-lg border text-xs font-semibold transition-all flex items-center gap-1.5 justify-center
                          ${on ? 'border-gold/50 bg-gold/10 text-gold' : 'border-border text-dim hover:border-border-2 hover:text-muted'}`}>
                        <span>{PLATFORM_ICONS[p]}</span>
                        <span className="truncate">{p.replace('_',' ').replace('apple music','Apple')}</span>
                      </button>
                    )
                  })}
                </div>
              </div>

              <div>
                <label className="label">Notes</label>
                <textarea className="input resize-none" rows={2}
                  placeholder="e.g. Featured artist, sample clearance status..."
                  value={form.notes}
                  onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
              </div>
            </div>

            <div className="flex gap-3 mt-8">
              <button className="btn-primary flex-1 justify-center py-3" onClick={handleAdd}>
                Register Song
              </button>
              <button className="btn-ghost py-3 px-6" onClick={() => setShowAdd(false)}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
