// app/dashboard/page.tsx
'use client'
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts'
import {
  DEMO_ARTIST, DEMO_SONGS, DEMO_MONTHLY_EARNINGS, DEMO_PLATFORM_EARNINGS,
  PENDING_COSOTA, UNCOLLECTED_RADIO, TOTAL_COLLECTED
} from '@/lib/mock-data'

export default function DashboardPage() {
  const uncollected = PENDING_COSOTA + UNCOLLECTED_RADIO
  const totalStreams = DEMO_SONGS.reduce((s, song) => s + song.total_streams, 0)

  return (
    <div className="p-10 max-w-[1200px] animate-fade-up">
      {/* Header */}
      <div className="mb-8">
        <p className="text-xs text-dim font-semibold tracking-[2px] uppercase mb-2">April 2026</p>
        <h1 className="font-display text-4xl font-extrabold tracking-tight text-white">
          Good morning, Justin 👋
        </h1>
        <p className="text-muted mt-2 text-sm">
          You have{' '}
          <span className="text-gold font-bold">${uncollected.toFixed(0)} in uncollected royalties</span>
          {' '}across COSOTA and radio airplay.{' '}
          <span className="text-teal font-semibold cursor-pointer hover:underline">Claim now →</span>
        </p>
      </div>

      {/* Alert */}
      <div className="flex items-center gap-4 bg-danger/8 border border-danger/20 rounded-xl px-5 py-4 mb-7">
        <span className="text-xl shrink-0">⚠️</span>
        <div className="flex-1 min-w-0">
          <span className="font-bold text-danger text-sm">1 song unregistered</span>
          <span className="text-muted text-sm"> — "CREOVA Anthem" has no ISRC code. You are missing royalties from YouTube streams.</span>
        </div>
        <button className="btn-danger shrink-0 text-xs">Register Now</button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-4 mb-7">
        {[
          { label: 'Total Streams', value: `${(totalStreams / 1000).toFixed(0)}K`, sub: 'All platforms', accent: 'teal' },
          { label: 'Monthly Listeners', value: `${(DEMO_ARTIST.wallet_balance_usd / 10).toFixed(1)}K`, sub: '+12% vs last month', accent: '' },
          { label: 'Collected', value: `$${TOTAL_COLLECTED.toFixed(0)}`, sub: 'Last 6 months', accent: 'teal' },
          { label: 'Uncollected', value: `$${uncollected.toFixed(0)}`, sub: 'COSOTA + radio', accent: 'danger' },
        ].map(stat => (
          <div key={stat.label} className={`stat-card ${stat.accent}`}>
            <p className="text-[11px] text-dim font-bold tracking-[1px] uppercase mb-3">{stat.label}</p>
            <p className="font-display text-3xl font-extrabold text-white tracking-tight">{stat.value}</p>
            <p className="text-xs text-dim mt-1">{stat.sub}</p>
          </div>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-[1.7fr_1fr] gap-5 mb-5">
        <div className="card">
          <div className="flex justify-between items-baseline mb-6">
            <div>
              <p className="font-display font-bold text-base">Earnings Trend</p>
              <p className="text-xs text-dim mt-1">Monthly royalties earned (USD)</p>
            </div>
            <p className="font-display text-2xl font-extrabold text-gold">${TOTAL_COLLECTED.toFixed(0)}</p>
          </div>
          <ResponsiveContainer width="100%" height={180}>
            <AreaChart data={DEMO_MONTHLY_EARNINGS}>
              <defs>
                <linearGradient id="goldGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#e8a030" stopOpacity={0.25} />
                  <stop offset="95%" stopColor="#e8a030" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="month" tick={{ fill: '#5a6880', fontSize: 12 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: '#5a6880', fontSize: 12 }} axisLine={false} tickLine={false} />
              <Tooltip
                contentStyle={{ background: '#1c2230', border: '1px solid #2e3a4e', borderRadius: 8, fontSize: 12 }}
                formatter={(v: number) => [`$${v}`, 'Earned']}
              />
              <Area type="monotone" dataKey="earned" stroke="#e8a030" strokeWidth={2} fill="url(#goldGrad)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="card">
          <p className="font-display font-bold text-base mb-1">Revenue by Platform</p>
          <p className="text-xs text-dim mb-5">Last 6 months</p>
          <ResponsiveContainer width="100%" height={110}>
            <PieChart>
              <Pie data={DEMO_PLATFORM_EARNINGS} cx="50%" cy="50%" innerRadius={32} outerRadius={52} dataKey="amount">
                {DEMO_PLATFORM_EARNINGS.map((p, i) => <Cell key={i} fill={p.color} />)}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-2.5 mt-4">
            {DEMO_PLATFORM_EARNINGS.map(p => (
              <div key={p.name} className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full shrink-0" style={{ background: p.color }} />
                  <span className="text-[13px] text-muted">{p.name}</span>
                </div>
                <span className="text-[13px] font-semibold text-white">${p.amount}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Top songs */}
      <div className="card">
        <div className="flex justify-between items-baseline mb-5">
          <p className="font-display font-bold text-base">Top Songs</p>
          <a href="/catalog" className="text-[13px] text-teal font-semibold hover:underline">View all →</a>
        </div>
        <div className="divide-y divide-border">
          {DEMO_SONGS.slice(0, 4).map((song, i) => (
            <div key={song.id} className="flex items-center gap-4 py-3.5">
              <span className="font-display font-extrabold text-xl text-border-2 w-7 text-center shrink-0">{i + 1}</span>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-[14px] text-white">{song.title}</p>
                <p className="text-[12px] text-dim mt-0.5">{song.genre} · {song.isrc ?? 'No ISRC'}</p>
              </div>
              <div className="text-right">
                <p className="font-display font-bold text-[15px] text-white">{song.total_streams.toLocaleString()}</p>
                <p className="text-[11px] text-dim">streams</p>
              </div>
              <div className="text-right w-20">
                <p className="font-display font-bold text-[15px] text-gold">${song.total_royalties_usd}</p>
                <p className="text-[11px] text-dim">royalties</p>
              </div>
              <span className={`shrink-0 ${
                song.status === 'active' ? 'badge-active' :
                song.status === 'pending_cosota' ? 'badge-pending' : 'badge-error'
              }`}>
                {song.status === 'active' ? '● Registered' :
                 song.status === 'pending_cosota' ? '◌ Pending' : '✕ Register'}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
