'use client'
// app/royalties/page.tsx
import { useState } from 'react'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts'
import {
  DEMO_ARTIST, DEMO_TRANSACTIONS, DEMO_MONTHLY_EARNINGS,
  DEMO_PLATFORM_EARNINGS, DEMO_AIRPLAY, DEMO_SONGS,
  PENDING_COSOTA, UNCOLLECTED_RADIO, TOTAL_COLLECTED,
} from '@/lib/mock-data'

export default function RoyaltiesPage() {
  const [showWithdraw, setShowWithdraw] = useState(false)
  const [amount, setAmount] = useState('')
  const [mpesa, setMpesa] = useState('')
  const [withdrawn, setWithdrawn] = useState(false)
  const [activeTab, setActiveTab] = useState<'overview' | 'transactions' | 'airplay'>('overview')
  const [claimedIds, setClaimedIds] = useState<string[]>([])

  const uncollected = PENDING_COSOTA + UNCOLLECTED_RADIO

  const handleWithdraw = () => {
    setShowWithdraw(false)
    setWithdrawn(true)
    setAmount('')
    setMpesa('')
    setTimeout(() => setWithdrawn(false), 5000)
  }

  const handleClaim = (id: string) => {
    setClaimedIds(prev => [...prev, id])
  }

  return (
    <div className="p-10 max-w-[1100px] animate-fade-up">
      {/* Header */}
      <div className="flex justify-between items-start mb-8">
        <div>
          <h1 className="font-display text-4xl font-extrabold tracking-tight mb-1.5">Royalty Wallet</h1>
          <p className="text-muted text-sm">All streaming, COSOTA, and radio earnings in one place</p>
        </div>
        <button className="btn-primary" onClick={() => setShowWithdraw(true)}>
          Withdraw via M-Pesa
        </button>
      </div>

      {/* Withdrawal success */}
      {withdrawn && (
        <div className="flex items-center gap-3 bg-teal/10 border border-teal/25 rounded-xl px-5 py-3.5 mb-6 text-teal text-sm font-semibold">
          ✓ Withdrawal initiated. Funds will arrive via M-Pesa within 24 hours. Reference: MPESA-{Date.now().toString().slice(-6)}
        </div>
      )}

      {/* Wallet cards */}
      <div className="grid grid-cols-3 gap-5 mb-8">
        {/* Main balance card */}
        <div className="relative rounded-2xl p-7 overflow-hidden" style={{ background: 'linear-gradient(135deg, #e8a030 0%, #f5c060 100%)' }}>
          <div className="absolute -top-6 -right-6 w-32 h-32 rounded-full bg-white/10" />
          <div className="absolute -bottom-8 -left-4 w-24 h-24 rounded-full bg-black/8" />
          <p className="relative text-[11px] font-bold tracking-[2px] uppercase text-black/60 mb-3">Available Balance</p>
          <p className="relative font-display text-5xl font-black text-black tracking-tight leading-none mb-1">
            ${DEMO_ARTIST.wallet_balance_usd.toLocaleString()}
          </p>
          <p className="relative text-sm text-black/50 mb-6">TZS {DEMO_ARTIST.wallet_balance_tzs.toLocaleString()}</p>
          <button onClick={() => setShowWithdraw(true)}
            className="relative bg-black/15 hover:bg-black/25 transition-colors border-none rounded-lg px-4 py-2 text-black font-bold text-sm cursor-pointer">
            Withdraw →
          </button>
        </div>

        {/* Pending COSOTA */}
        <div className="stat-card">
          <p className="text-[10px] text-dim font-bold tracking-[1.5px] uppercase mb-3">Pending — COSOTA</p>
          <p className="font-display text-4xl font-extrabold text-gold leading-none mb-2">${PENDING_COSOTA.toFixed(2)}</p>
          <p className="text-[12px] text-dim leading-relaxed mb-4">
            Royalties submitted for 2 songs awaiting COSOTA distribution. Expected payout: May 2026.
          </p>
          <div className="flex items-center gap-2 bg-gold/8 border border-gold/20 rounded-lg px-3 py-2">
            <span className="text-gold animate-pulse-ring w-2 h-2 rounded-full bg-gold shrink-0" />
            <span className="text-gold text-xs font-semibold">Under review at COSOTA</span>
          </div>
        </div>

        {/* Uncollected radio */}
        <div className="stat-card danger">
          <p className="text-[10px] text-dim font-bold tracking-[1.5px] uppercase mb-3">Uncollected — Radio & TV</p>
          <p className="font-display text-4xl font-extrabold text-danger leading-none mb-2">${UNCOLLECTED_RADIO.toFixed(2)}</p>
          <p className="text-[12px] text-dim leading-relaxed mb-4">
            {DEMO_AIRPLAY.filter(a => !a.claimed).length} airplay detections via SautiOS monitoring. Submit claim to COSOTA to recover.
          </p>
          <button className="btn-danger text-xs py-2" onClick={() => setActiveTab('airplay')}>
            View & Claim →
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-surface border border-border rounded-xl p-1 mb-6 w-fit">
        {[['overview','Overview'],['transactions','Transactions'],['airplay','Airplay Monitoring']].map(([val, label]) => (
          <button key={val}
            onClick={() => setActiveTab(val as any)}
            className={`px-5 py-2 rounded-lg text-[13px] font-semibold transition-all
              ${activeTab === val ? 'bg-gold text-black' : 'text-muted hover:text-white'}`}>
            {label}
            {val === 'airplay' && DEMO_AIRPLAY.filter(a => !a.claimed && !claimedIds.includes(a.id)).length > 0 && (
              <span className="ml-2 bg-danger text-white text-[10px] font-bold rounded-full px-1.5 py-0.5">
                {DEMO_AIRPLAY.filter(a => !a.claimed && !claimedIds.includes(a.id)).length}
              </span>
            )}
          </button>
        ))}
      </div>

      {activeTab === 'overview' && (
        <div className="grid grid-cols-[1.4fr_1fr] gap-5">
          {/* Monthly bar chart */}
          <div className="card">
            <p className="font-display font-bold text-base mb-1">Monthly Earnings</p>
            <p className="text-xs text-dim mb-6">USD collected per month (last 6 months)</p>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={DEMO_MONTHLY_EARNINGS} barSize={32}>
                <XAxis dataKey="month" tick={{ fill: '#5a6880', fontSize: 12 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: '#5a6880', fontSize: 12 }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{ background: '#1c2230', border: '1px solid #2e3a4e', borderRadius: 8, fontSize: 12 }}
                  formatter={(v: number) => [`$${v}`, 'Earned']}
                />
                <Bar dataKey="earned" radius={[5, 5, 0, 0]}>
                  {DEMO_MONTHLY_EARNINGS.map((_, i) => (
                    <Cell key={i} fill={i === DEMO_MONTHLY_EARNINGS.length - 1 ? '#e8a030' : '#232b38'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Platform breakdown */}
          <div className="card">
            <p className="font-display font-bold text-base mb-6">Revenue by Platform</p>
            <div className="space-y-5">
              {DEMO_PLATFORM_EARNINGS.map(p => {
                const pct = (p.amount / TOTAL_COLLECTED * 100).toFixed(0)
                return (
                  <div key={p.name}>
                    <div className="flex justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className="w-2.5 h-2.5 rounded-full shrink-0" style={{ background: p.color }} />
                        <span className="text-[13px] text-muted font-medium">{p.name}</span>
                      </div>
                      <div className="text-right">
                        <span className="text-[13px] font-bold text-white">${p.amount}</span>
                        <span className="text-[11px] text-dim ml-2">{pct}%</span>
                      </div>
                    </div>
                    <div className="bg-bg-2 rounded-full h-1.5 overflow-hidden">
                      <div className="h-full rounded-full transition-all duration-700" style={{ width: `${pct}%`, background: p.color }} />
                    </div>
                    <p className="text-[11px] text-dim mt-1">{p.streams.toLocaleString()} streams</p>
                  </div>
                )
              })}
            </div>
            <div className="mt-6 pt-5 border-t border-border flex justify-between">
              <span className="text-sm text-muted font-semibold">Total Collected</span>
              <span className="font-display font-extrabold text-lg text-white">${TOTAL_COLLECTED.toFixed(2)}</span>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'transactions' && (
        <div className="card p-0 overflow-hidden">
          <div className="px-6 py-4 border-b border-border">
            <p className="font-display font-bold text-base">Transaction History</p>
          </div>
          <div className="divide-y divide-border">
            {DEMO_TRANSACTIONS.map(tx => {
              const isCredit = tx.amount_usd > 0
              return (
                <div key={tx.id} className="flex items-center gap-4 px-6 py-4 hover:bg-surface-2/30 transition-colors">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-lg shrink-0
                    ${isCredit ? 'bg-teal/10' : 'bg-danger/10'}`}>
                    {isCredit ? '↑' : '↓'}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-[14px] text-white">{tx.description}</p>
                    <p className="text-[12px] text-dim mt-0.5">
                      {tx.platform && `${tx.platform} · `}
                      {new Date(tx.created_at).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}
                      {tx.reference && ` · Ref: ${tx.reference}`}
                    </p>
                  </div>
                  <div className="text-right shrink-0">
                    <p className={`font-display font-extrabold text-lg ${isCredit ? 'text-teal' : 'text-danger'}`}>
                      {isCredit ? '+' : ''}${Math.abs(tx.amount_usd).toFixed(2)}
                    </p>
                    {tx.fee_usd > 0 && <p className="text-[11px] text-dim">Fee: ${tx.fee_usd.toFixed(2)}</p>}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}

      {activeTab === 'airplay' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between mb-2">
            <div>
              <p className="font-display font-bold text-base">Radio & TV Airplay Detections</p>
              <p className="text-[13px] text-muted mt-1">SautiOS monitors Tanzanian and regional stations for your music. Submit claims to COSOTA to collect royalties.</p>
            </div>
            <button className="btn-primary text-sm">Claim All Unclaimed</button>
          </div>

          {DEMO_AIRPLAY.map(detection => {
            const song = DEMO_SONGS.find(s => s.id === detection.song_id)
            const isClaimed = detection.claimed || claimedIds.includes(detection.id)
            return (
              <div key={detection.id} className="card flex items-center gap-4">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-xl shrink-0
                  ${detection.station_type === 'tv' ? 'bg-teal/10' : 'bg-gold/10'}`}>
                  {detection.station_type === 'tv' ? '📺' : '📻'}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5">
                    <p className="font-semibold text-[14px] text-white">{detection.station_name}</p>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-muted bg-surface-2 border border-border rounded px-2 py-0.5">
                      {detection.country}
                    </span>
                  </div>
                  <p className="text-[13px] text-muted">
                    "{song?.title ?? 'Unknown'}" · {new Date(detection.detected_at).toLocaleString('en-GB', { dateStyle: 'medium', timeStyle: 'short' })}
                    {detection.duration_seconds && ` · ${Math.floor(detection.duration_seconds / 60)}m ${detection.duration_seconds % 60}s`}
                  </p>
                  {detection.cosota_claim_ref && (
                    <p className="text-[11px] text-teal mt-0.5 font-mono-custom">Claim ref: {detection.cosota_claim_ref}</p>
                  )}
                </div>
                <div className="shrink-0">
                  {isClaimed
                    ? <span className="badge-active">✓ Claimed</span>
                    : <button className="btn-primary text-xs py-1.5 px-4" onClick={() => handleClaim(detection.id)}>Submit Claim</button>
                  }
                </div>
              </div>
            )
          })}
        </div>
      )}

      {/* Withdraw modal */}
      {showWithdraw && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4">
          <div className="bg-surface border border-border rounded-2xl p-10 w-[440px]">
            <h2 className="font-display font-extrabold text-2xl mb-1.5">Withdraw Funds</h2>
            <p className="text-muted text-[13px] mb-7">Transfer to your M-Pesa number. Arrives within 24 hours. Fee: 1.5%.</p>

            <div className="space-y-5">
              <div>
                <label className="label">Amount (USD)</label>
                <input className="input font-display font-bold text-lg" type="number" placeholder="0.00"
                  max={DEMO_ARTIST.wallet_balance_usd} value={amount} onChange={e => setAmount(e.target.value)} />
                <p className="text-[11px] text-dim mt-1.5">
                  Available: <span className="text-gold font-semibold">${DEMO_ARTIST.wallet_balance_usd}</span>
                  {amount && parseFloat(amount) > 0 && (
                    <> · You receive: <span className="text-teal font-semibold">${(parseFloat(amount) * 0.985).toFixed(2)}</span></>
                  )}
                </p>
              </div>
              <div>
                <label className="label">M-Pesa Number</label>
                <input className="input" type="tel" placeholder="+255 7XX XXX XXX"
                  value={mpesa} onChange={e => setMpesa(e.target.value)} />
              </div>
              <div className="bg-bg-2 border border-border rounded-xl p-4 text-[12px] text-dim space-y-1.5">
                <p>✓ Powered by Vodacom M-Pesa Business API</p>
                <p>✓ Funds arrive within 24 hours</p>
                <p>✓ 1.5% transfer fee applies</p>
                <p>✓ All withdrawals are logged for tax purposes</p>
              </div>
            </div>

            <div className="flex gap-3 mt-8">
              <button className="btn-primary flex-1 justify-center py-3" onClick={handleWithdraw}
                disabled={!amount || !mpesa || parseFloat(amount) <= 0}>
                Confirm Withdrawal
              </button>
              <button className="btn-ghost py-3 px-6" onClick={() => setShowWithdraw(false)}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
