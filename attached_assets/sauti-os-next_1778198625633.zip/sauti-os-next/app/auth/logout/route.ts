// app/auth/logout/route.ts
import { NextResponse } from 'next/server'

export async function GET() {
  // In production: clear Supabase session cookies here
  return NextResponse.redirect(new URL('/', process.env.NEXT_PUBLIC_APP_URL ?? 'http://localhost:3000'))
}
