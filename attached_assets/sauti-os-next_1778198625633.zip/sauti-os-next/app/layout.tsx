// app/layout.tsx
import type { Metadata } from 'next'
import { Syne, DM_Sans, DM_Mono } from 'next/font/google'
import './globals.css'

const syne = Syne({
  subsets: ['latin'],
  variable: '--font-syne',
  weight: ['400', '600', '700', '800'],
})

const dmSans = DM_Sans({
  subsets: ['latin'],
  variable: '--font-dm-sans',
  weight: ['300', '400', '500', '600'],
})

const dmMono = DM_Mono({
  subsets: ['latin'],
  variable: '--font-dm-mono',
  weight: ['400', '500'],
})

export const metadata: Metadata = {
  title: 'SautiOS — African Artist Management Platform',
  description: 'Register your catalog, track streams, collect royalties, manage contracts and events. Built for East African musicians.',
  keywords: ['music', 'Tanzania', 'East Africa', 'COSOTA', 'royalties', 'artist management', 'Bongo Flava'],
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${syne.variable} ${dmSans.variable} ${dmMono.variable}`}>
      <body className="bg-bg text-white font-body antialiased">
        {children}
      </body>
    </html>
  )
}
