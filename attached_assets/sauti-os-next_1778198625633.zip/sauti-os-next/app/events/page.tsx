'use client'
// app/events/page.tsx
import { useState } from 'react'
import { DEMO_EVENTS } from '@/lib/mock-data'
import type { Event, EventStatus } from '@/types/database'

const STATUS_CONFIG: Record<EventStatus, { badge: string; label: string }> = {
  draft:     { badge: 'badge-neutral', label: '○ Draft' },
  on_sale:   { badge: 'badge-active',  label: '● On Sale' },
  sold_out:  { badge: 'badge-pending', label: '⚡ Sold Out' },
  completed: { badge: 'badge-neutral', label: '✓ Completed' },
  cancelled: { badge: 'badge-error',   label: '✕ Cancelled' },
}

export default function EventsPage() {
  const [events, setEvents] = useState<Event[]>(DEMO_EVENTS)
  const [showNew, setShowNew] = useState(false)
  const [selected, setSelected] = useState<Event | null>(null)
  const [showTicketSale, setShowTicketSale] = useState(false)
  const [ticketForm, setTicketForm] = useState({ name: '', phone: '', email: '', qty: '1' })
  const [ticketSold, setTicketSold] = useState(false)
  const [form, setForm] = useState({
    name: '', venue: '', city: 'Dar es Salaam', country: 'TZ',
    event_date: '', doors_open: '18:00', capacity: '500',
    ticket_price_tzs: '', ticket_price_usd: '', description: '',
  })

  const totalRevenue = events.reduce((s, e) => s + e.total_revenue_tzs, 0)
  const totalTickets = events.reduce((s, e) => s + e.tickets_sold, 0)

  const handleCreate = () => {
    if (!form.name || !form.event_date) return
    const newEvent: Event = {
      id: `e-${Date.now()}`,
      artist_id: 'demo-artist-001',
      name: form.name,
      description: form.description || null,
      venue: form.venue || null,
      city: form.city,
      country: form.country,
      event_date: new Date(form.event_date).toISOString(),
      doors_open: form.doors_open || null,
      capacity: parseInt(form.capacity) || 0,
      tickets_sold: 0,
      ticket_price_tzs: form.ticket_price_tzs ? parseFloat(form.ticket_price_tzs) : null,
      ticket_price_usd: form.ticket_price_usd ? parseFloat(form.ticket_price_usd) : null,
      status: 'draft',
      poster_url: null,
      total_revenue_tzs: 0,
      platform_fee_pct: 3,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }
    setEvents(prev => [newEvent, ...prev])
    setShowNew(false)
    setForm({ name: '', venue: '', city: 'Dar es Salaam', country: 'TZ', event_date: '', doors_open: '18:00', capacity: '500', ticket_price_tzs: '', ticket_price_usd: '', description: '' })
  }

  const handleTicketSale = () => {
    if (!selected || !ticketForm.name || !ticketForm.phone) return
    const qty = parseInt(ticketForm.qty) || 1
    setEvents(prev => prev.map(e =>
      e.id === selected.id
        ? { ...e, tickets_sold: e.tickets_sold + qty, total_revenue_tzs: e.total_revenue_tzs + (e.ticket_price_tzs ?? 0) * qty }
        : e
    ))
    setShowTicketSale(false)
    setTicketSold(true)
    setTicketForm({ name: '', phone: '', email: '', qty: '1' })
    setTimeout(() => setTicketSold(false), 5000)
  }

  const pct = (event: Event) => event.capacity > 0 ? Math.round(event.tickets_sold / event.capacity * 100) : 0

  return (
    <div className="p-10 max-w-[1100px] animate-fade-up">
      {/* Header */}
      <div className="flex justify-between items-start mb-8">
        <div>
          <h1 className="font-display text-4xl font-extrabold tracking-tight mb-1.5">Events</h1>
          <p className="text-muted text-sm">{events.length} events · {totalTickets.toLocaleString()} tickets sold</p>
        </div>
        <button className="btn-primary" onClick={() => setShowNew(true)}>+ Create Event</button>
      </div>

      {ticketSold && (
        <div className="flex items-center gap-3 bg-teal/10 border border-teal/25 rounded-xl px-5 py-3.5 mb-6 text-teal text-sm font-semibold">
          ✓ Ticket sold! M-Pesa payment confirmed. Ticket code sent via SMS.
        </div>
      )}

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4 mb-7">
        <div className="stat-card teal">
          <p className="text-[11px] text-dim font-bold tracking-[1px] uppercase mb-3">Total Revenue</p>
          <p className="font-display text-3xl font-extrabold text-white">TZS {(totalRevenue / 1_000_000).toFixed(2)}M</p>
          <p className="text-xs text-dim mt-1">After 3% SautiOS fee</p>
        </div>
        <div className="stat-card">
          <p className="text-[11px] text-dim font-bold tracking-[1px] uppercase mb-3">Total Tickets Sold</p>
          <p className="font-display text-3xl font-extrabold text-white">{totalTickets.toLocaleString()}</p>
          <p className="text-xs text-dim mt-1">Across {events.filter(e => e.status === 'on_sale' || e.status === 'completed').length} events</p>
        </div>
        <div className="stat-card">
          <p className="text-[11px] text-dim font-bold tracking-[1px] uppercase mb-3">Active Events</p>
          <p className="font-display text-3xl font-extrabold text-gold">{events.filter(e => e.status === 'on_sale').length}</p>
          <p className="text-xs text-dim mt-1">Currently on sale</p>
        </div>
      </div>

      {/* Event cards */}
      <div className="space-y-4 mb-6">
        {events.map(event => (
          <div key={event.id} className="card-hover cursor-pointer" onClick={() => setSelected(event)}>
            <div className="flex items-start gap-6">
              {/* Date block */}
              <div className="shrink-0 w-16 text-center bg-surface-2 border border-border rounded-xl p-2">
                <p className="text-[10px] text-dim font-bold uppercase tracking-wider">
                  {new Date(event.event_date).toLocaleString('en-GB', { month: 'short' })}
                </p>
                <p className="font-display font-extrabold text-2xl text-white leading-none">
                  {new Date(event.event_date).getDate()}
                </p>
                <p className="text-[10px] text-dim mt-0.5">
                  {new Date(event.event_date).getFullYear()}
                </p>
              </div>

              {/* Details */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-3 mb-1">
                  <h3 className="font-display font-bold text-[16px] text-white">{event.name}</h3>
                  <span className={STATUS_CONFIG[event.status].badge}>{STATUS_CONFIG[event.status].label}</span>
                </div>
                <p className="text-[13px] text-muted">
                  {event.venue && `${event.venue} · `}{event.city}, {event.country}
                  {event.doors_open && ` · Doors ${event.doors_open}`}
                </p>
                {event.description && (
                  <p className="text-[12px] text-dim mt-1.5 line-clamp-1">{event.description}</p>
                )}
                {/* Ticket progress */}
                {event.capacity > 0 && (
                  <div className="mt-3">
                    <div className="flex justify-between text-[11px] text-dim mb-1.5">
                      <span>{event.tickets_sold.toLocaleString()} sold</span>
                      <span>{event.capacity.toLocaleString()} capacity · {pct(event)}%</span>
                    </div>
                    <div className="bg-bg-2 rounded-full h-1.5 overflow-hidden">
                      <div className={`h-full rounded-full transition-all duration-700 ${pct(event) > 80 ? 'bg-danger' : pct(event) > 50 ? 'bg-gold' : 'bg-teal'}`}
                        style={{ width: `${Math.min(pct(event), 100)}%` }} />
                    </div>
                  </div>
                )}
              </div>

              {/* Revenue */}
              <div className="shrink-0 text-right">
                <p className="font-display font-extrabold text-xl text-white">
                  TZS {(event.total_revenue_tzs / 1000).toFixed(0)}K
                </p>
                <p className="text-[11px] text-dim mt-0.5">
                  {event.ticket_price_tzs ? `TZS ${event.ticket_price_tzs.toLocaleString()}/ticket` : event.ticket_price_usd ? `$${event.ticket_price_usd}/ticket` : 'Price TBD'}
                </p>
              </div>
            </div>
          </div>
        ))}
        {events.length === 0 && (
          <div className="text-center py-20 text-dim">
            <p className="text-5xl mb-4">🎤</p>
            <p className="text-muted font-semibold text-lg">No events yet</p>
            <button className="btn-primary mt-4" onClick={() => setShowNew(true)}>Create Your First Event</button>
          </div>
        )}
      </div>

      {/* Event detail drawer */}
      {selected && (
        <div className="fixed inset-0 bg-black/70 z-50 flex justify-end" onClick={() => setSelected(null)}>
          <div className="w-[500px] bg-surface border-l border-border h-full overflow-y-auto p-8" onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-start mb-6">
              <div>
                <span className={STATUS_CONFIG[selected.status].badge}>{STATUS_CONFIG[selected.status].label}</span>
                <h2 className="font-display font-extrabold text-xl mt-2">{selected.name}</h2>
                <p className="text-muted text-sm">{selected.city}, {selected.country}</p>
              </div>
              <button onClick={() => setSelected(null)} className="text-dim hover:text-white text-xl">✕</button>
            </div>

            {/* Key metrics */}
            <div className="grid grid-cols-2 gap-3 mb-6">
              {[
                { label: 'Date', value: new Date(selected.event_date).toLocaleDateString('en-GB', { dateStyle: 'long' }) },
                { label: 'Venue', value: selected.venue ?? '—' },
                { label: 'Capacity', value: selected.capacity.toLocaleString() },
                { label: 'Tickets Sold', value: `${selected.tickets_sold.toLocaleString()} (${pct(selected)}%)` },
                { label: 'Ticket Price', value: selected.ticket_price_tzs ? `TZS ${selected.ticket_price_tzs.toLocaleString()}` : selected.ticket_price_usd ? `$${selected.ticket_price_usd}` : '—' },
                { label: 'Revenue', value: `TZS ${selected.total_revenue_tzs.toLocaleString()}` },
              ].map(([label, value]) => (
                <div key={String(label)} className="bg-bg-2 rounded-xl p-3 border border-border">
                  <p className="text-[10px] text-dim font-bold uppercase tracking-wider mb-1">{label as string}</p>
                  <p className="text-sm font-semibold text-white">{value as string}</p>
                </div>
              ))}
            </div>

            {selected.description && (
              <div className="mb-6">
                <p className="text-[10px] text-dim font-bold uppercase tracking-wider mb-2">Description</p>
                <p className="text-[13px] text-muted leading-relaxed bg-bg-2 rounded-xl p-4 border border-border">{selected.description}</p>
              </div>
            )}

            {/* Ticket progress bar */}
            {selected.capacity > 0 && (
              <div className="mb-6">
                <div className="flex justify-between text-[12px] text-dim mb-2">
                  <span>{selected.tickets_sold} sold</span>
                  <span>{selected.capacity} capacity</span>
                </div>
                <div className="bg-bg-2 rounded-full h-3 overflow-hidden">
                  <div className={`h-full rounded-full ${pct(selected) > 80 ? 'bg-danger' : pct(selected) > 50 ? 'bg-gold' : 'bg-teal'}`}
                    style={{ width: `${Math.min(pct(selected), 100)}%` }} />
                </div>
                <p className="text-[11px] text-dim mt-1">{selected.capacity - selected.tickets_sold} tickets remaining</p>
              </div>
            )}

            <div className="space-y-3 mt-6">
              {selected.status === 'on_sale' && (
                <button className="btn-primary w-full justify-center py-3" onClick={() => setShowTicketSale(true)}>
                  Sell Ticket (M-Pesa)
                </button>
              )}
              {selected.status === 'draft' && (
                <button className="btn-primary w-full justify-center py-3"
                  onClick={() => setEvents(prev => prev.map(e => e.id === selected.id ? { ...e, status: 'on_sale' as EventStatus } : e))}>
                  Publish & Go On Sale
                </button>
              )}
              <div className="grid grid-cols-2 gap-3">
                <button className="btn-ghost justify-center py-2.5">Share Event</button>
                <button className="btn-ghost justify-center py-2.5">Edit Details</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Ticket sale modal */}
      {showTicketSale && selected && (
        <div className="fixed inset-0 bg-black/70 z-[60] flex items-center justify-center p-4">
          <div className="bg-surface border border-border rounded-2xl p-8 w-[420px]">
            <h2 className="font-display font-extrabold text-xl mb-1.5">Sell Ticket</h2>
            <p className="text-muted text-[13px] mb-6">{selected.name} · {selected.ticket_price_tzs ? `TZS ${selected.ticket_price_tzs.toLocaleString()}` : `$${selected.ticket_price_usd}`}</p>
            <div className="space-y-4">
              {[
                { label: 'Buyer Name *', key: 'name', type: 'text', ph: 'Full name' },
                { label: 'M-Pesa Phone *', key: 'phone', type: 'tel', ph: '+255 7XX XXX XXX' },
                { label: 'Email (optional)', key: 'email', type: 'email', ph: 'buyer@email.com' },
              ].map(f => (
                <div key={f.key}>
                  <label className="label">{f.label}</label>
                  <input className="input" type={f.type} placeholder={f.ph}
                    value={(ticketForm as any)[f.key]} onChange={e => setTicketForm(tf => ({ ...tf, [f.key]: e.target.value }))} />
                </div>
              ))}
              <div>
                <label className="label">Quantity</label>
                <select className="input" value={ticketForm.qty} onChange={e => setTicketForm(tf => ({ ...tf, qty: e.target.value }))}>
                  {[1,2,3,4,5].map(n => <option key={n} value={n}>{n} ticket{n > 1 ? 's' : ''}</option>)}
                </select>
              </div>
              <div className="bg-bg-2 border border-border rounded-xl p-4 space-y-2 text-[13px]">
                <div className="flex justify-between text-muted">
                  <span>{ticketForm.qty}x ticket</span>
                  <span>TZS {((selected.ticket_price_tzs ?? 0) * parseInt(ticketForm.qty)).toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-muted">
                  <span>SautiOS fee (3%)</span>
                  <span>TZS {((selected.ticket_price_tzs ?? 0) * parseInt(ticketForm.qty) * 0.03).toLocaleString()}</span>
                </div>
                <div className="flex justify-between font-bold text-white pt-2 border-t border-border">
                  <span>M-Pesa total</span>
                  <span className="text-gold">TZS {((selected.ticket_price_tzs ?? 0) * parseInt(ticketForm.qty)).toLocaleString()}</span>
                </div>
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <button className="btn-primary flex-1 justify-center py-3" onClick={handleTicketSale}>
                Charge M-Pesa
              </button>
              <button className="btn-ghost py-3 px-5" onClick={() => setShowTicketSale(false)}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      {/* New event modal */}
      {showNew && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4">
          <div className="bg-surface border border-border rounded-2xl p-10 w-[540px] max-h-[90vh] overflow-y-auto">
            <h2 className="font-display font-extrabold text-2xl mb-1.5">Create Event</h2>
            <p className="text-muted text-[13px] mb-7">Events created here can accept M-Pesa ticket payments. SautiOS charges 3% on each ticket.</p>
            <div className="space-y-5">
              {[
                { label: 'Event Name *', key: 'name', type: 'text', ph: 'e.g. CREOVA LIVE — Dar es Salaam' },
                { label: 'Venue', key: 'venue', type: 'text', ph: 'e.g. Mlimani City Amphitheatre' },
                { label: 'Description', key: 'description', type: 'textarea', ph: 'Describe your event...' },
              ].map(f => (
                <div key={f.key}>
                  <label className="label">{f.label}</label>
                  {f.type === 'textarea'
                    ? <textarea className="input resize-none" rows={3} placeholder={f.ph} value={(form as any)[f.key]} onChange={e => setForm(ff => ({ ...ff, [f.key]: e.target.value }))} />
                    : <input className="input" type={f.type} placeholder={f.ph} value={(form as any)[f.key]} onChange={e => setForm(ff => ({ ...ff, [f.key]: e.target.value }))} />
                  }
                </div>
              ))}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="label">City</label>
                  <input className="input" value={form.city} onChange={e => setForm(f => ({ ...f, city: e.target.value }))} />
                </div>
                <div>
                  <label className="label">Country</label>
                  <select className="input" value={form.country} onChange={e => setForm(f => ({ ...f, country: e.target.value }))}>
                    <option value="TZ">🇹🇿 Tanzania</option>
                    <option value="KE">🇰🇪 Kenya</option>
                    <option value="UG">🇺🇬 Uganda</option>
                    <option value="CA">🇨🇦 Canada</option>
                    <option value="GB">🇬🇧 UK</option>
                  </select>
                </div>
                <div>
                  <label className="label">Event Date *</label>
                  <input className="input" type="datetime-local" value={form.event_date} onChange={e => setForm(f => ({ ...f, event_date: e.target.value }))} />
                </div>
                <div>
                  <label className="label">Capacity</label>
                  <input className="input" type="number" value={form.capacity} onChange={e => setForm(f => ({ ...f, capacity: e.target.value }))} />
                </div>
                <div>
                  <label className="label">Ticket Price (TZS)</label>
                  <input className="input" type="number" placeholder="15000" value={form.ticket_price_tzs} onChange={e => setForm(f => ({ ...f, ticket_price_tzs: e.target.value }))} />
                </div>
                <div>
                  <label className="label">Ticket Price (USD)</label>
                  <input className="input" type="number" placeholder="6" value={form.ticket_price_usd} onChange={e => setForm(f => ({ ...f, ticket_price_usd: e.target.value }))} />
                </div>
              </div>
            </div>
            <div className="flex gap-3 mt-8">
              <button className="btn-primary flex-1 justify-center py-3" onClick={handleCreate}>Create Event</button>
              <button className="btn-ghost py-3 px-6" onClick={() => setShowNew(false)}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
