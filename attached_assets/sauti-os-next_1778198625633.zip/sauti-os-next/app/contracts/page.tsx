'use client'
// app/contracts/page.tsx
import { useState } from 'react'
import { DEMO_CONTRACTS } from '@/lib/mock-data'
import type { Contract, ContractType, ContractStatus } from '@/types/database'

const STATUS_BADGE: Record<ContractStatus, string> = {
  draft: 'badge-neutral',
  pending_signature: 'badge-pending',
  active: 'badge-active',
  completed: 'badge-neutral',
  cancelled: 'badge-error',
  disputed: 'badge-error',
}

const STATUS_LABEL: Record<ContractStatus, string> = {
  draft: '○ Draft',
  pending_signature: '◌ Awaiting Signature',
  active: '● Active',
  completed: '✓ Completed',
  cancelled: '✕ Cancelled',
  disputed: '! Disputed',
}

const TYPE_COLORS: Record<ContractType, string> = {
  performance: 'text-gold',
  brand_deal: 'text-teal',
  sync_license: '#a78bfa',
  management: '#60a5fa',
  distribution: '#f472b6',
}

const CONTRACT_TYPES: ContractType[] = ['performance', 'brand_deal', 'sync_license', 'management', 'distribution']

export default function ContractsPage() {
  const [contracts, setContracts] = useState<Contract[]>(DEMO_CONTRACTS)
  const [showNew, setShowNew] = useState(false)
  const [activeFilter, setActiveFilter] = useState<string>('all')
  const [selected, setSelected] = useState<Contract | null>(null)
  const [form, setForm] = useState({
    title: '', counterparty: '', counterparty_email: '',
    contract_type: 'performance' as ContractType,
    value_usd: '', currency: 'USD', start_date: '', end_date: '', notes: '',
  })

  const filtered = activeFilter === 'all' ? contracts : contracts.filter(c => c.status === activeFilter)
  const totalValue = contracts.filter(c => c.status !== 'cancelled').reduce((s, c) => s + (c.value_usd ?? 0), 0)
  const active = contracts.filter(c => c.status === 'active').length
  const pending = contracts.filter(c => c.status === 'pending_signature').length

  const handleCreate = () => {
    if (!form.title || !form.counterparty) return
    const newContract: Contract = {
      id: `c-${Date.now()}`,
      artist_id: 'demo-artist-001',
      contract_type: form.contract_type,
      title: form.title,
      counterparty: form.counterparty,
      counterparty_email: form.counterparty_email || null,
      value_usd: form.value_usd ? parseFloat(form.value_usd) : null,
      value_tzs: null,
      currency: form.currency,
      status: 'draft',
      signed_date: null,
      start_date: form.start_date || null,
      end_date: form.end_date || null,
      terms_text: null,
      file_url: null,
      notes: form.notes || null,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }
    setContracts(prev => [newContract, ...prev])
    setShowNew(false)
    setForm({ title: '', counterparty: '', counterparty_email: '', contract_type: 'performance', value_usd: '', currency: 'USD', start_date: '', end_date: '', notes: '' })
  }

  return (
    <div className="p-10 max-w-[1100px] animate-fade-up">
      {/* Header */}
      <div className="flex justify-between items-start mb-8">
        <div>
          <h1 className="font-display text-4xl font-extrabold tracking-tight mb-1.5">Contracts</h1>
          <p className="text-muted text-sm">{contracts.length} contracts · ${totalValue.toLocaleString()} total value</p>
        </div>
        <button className="btn-primary" onClick={() => setShowNew(true)}>+ New Contract</button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4 mb-7">
        <div className="stat-card">
          <p className="text-[11px] text-dim font-bold tracking-[1px] uppercase mb-3">Total Portfolio Value</p>
          <p className="font-display text-3xl font-extrabold text-white">${totalValue.toLocaleString()}</p>
          <p className="text-xs text-dim mt-1">Across all active contracts</p>
        </div>
        <div className="stat-card teal">
          <p className="text-[11px] text-dim font-bold tracking-[1px] uppercase mb-3">Active Contracts</p>
          <p className="font-display text-3xl font-extrabold text-white">{active}</p>
          <p className="text-xs text-dim mt-1">Currently in effect</p>
        </div>
        <div className="stat-card">
          <p className="text-[11px] text-dim font-bold tracking-[1px] uppercase mb-3">Awaiting Signature</p>
          <p className="font-display text-3xl font-extrabold text-gold">{pending}</p>
          <p className="text-xs text-dim mt-1">Action required</p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex gap-1 mb-6 bg-surface border border-border rounded-xl p-1 w-fit">
        {[['all', 'All'], ['active', 'Active'], ['pending_signature', 'Pending'], ['draft', 'Draft'], ['completed', 'Completed']].map(([val, label]) => (
          <button key={val}
            onClick={() => setActiveFilter(val)}
            className={`px-4 py-2 rounded-lg text-[13px] font-semibold transition-all
              ${activeFilter === val ? 'bg-gold text-black' : 'text-muted hover:text-white'}`}>
            {label}
          </button>
        ))}
      </div>

      {/* Contract list */}
      <div className="space-y-3 mb-6">
        {filtered.map(contract => (
          <div key={contract.id}
            className="card-hover cursor-pointer"
            onClick={() => setSelected(contract)}>
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-3 mb-1">
                  <span className={`text-xs font-bold uppercase tracking-wider ${TYPE_COLORS[contract.contract_type] ?? 'text-muted'}`}>
                    {contract.contract_type.replace('_', ' ')}
                  </span>
                  <span className={STATUS_BADGE[contract.status]}>{STATUS_LABEL[contract.status]}</span>
                </div>
                <h3 className="font-semibold text-[15px] text-white mb-0.5">{contract.title}</h3>
                <p className="text-[13px] text-muted">{contract.counterparty}</p>
                {contract.notes && <p className="text-[12px] text-dim mt-1.5 line-clamp-1">{contract.notes}</p>}
              </div>
              <div className="text-right shrink-0">
                {contract.value_usd && (
                  <p className="font-display font-extrabold text-xl text-white">${contract.value_usd.toLocaleString()}</p>
                )}
                <p className="text-[11px] text-dim mt-0.5">
                  {contract.signed_date
                    ? `Signed ${new Date(contract.signed_date).toLocaleDateString()}`
                    : contract.start_date
                    ? `Starts ${new Date(contract.start_date).toLocaleDateString()}`
                    : 'Not yet signed'}
                </p>
              </div>
            </div>
          </div>
        ))}
        {filtered.length === 0 && (
          <div className="text-center py-16 text-dim">
            <p className="text-4xl mb-3">📋</p>
            <p className="font-semibold text-muted">No contracts in this category</p>
            <button onClick={() => setShowNew(true)} className="btn-primary mt-4">+ Create First Contract</button>
          </div>
        )}
      </div>

      {/* Detail drawer */}
      {selected && (
        <div className="fixed inset-0 bg-black/70 z-50 flex justify-end" onClick={() => setSelected(null)}>
          <div className="w-[480px] bg-surface border-l border-border h-full overflow-y-auto p-8" onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-start mb-6">
              <div>
                <span className={`text-xs font-bold uppercase tracking-wider ${TYPE_COLORS[selected.contract_type] ?? 'text-muted'}`}>
                  {selected.contract_type.replace('_', ' ')}
                </span>
                <h2 className="font-display font-bold text-xl mt-1">{selected.title}</h2>
              </div>
              <button onClick={() => setSelected(null)} className="text-dim hover:text-white text-xl">✕</button>
            </div>
            <div className="space-y-5">
              {[
                ['Status', <span className={STATUS_BADGE[selected.status]}>{STATUS_LABEL[selected.status]}</span>],
                ['Counterparty', selected.counterparty],
                ['Email', selected.counterparty_email ?? '—'],
                ['Value', selected.value_usd ? `$${selected.value_usd.toLocaleString()} ${selected.currency}` : '—'],
                ['Signed', selected.signed_date ? new Date(selected.signed_date).toLocaleDateString() : 'Not yet signed'],
                ['Start Date', selected.start_date ? new Date(selected.start_date).toLocaleDateString() : '—'],
                ['End Date', selected.end_date ? new Date(selected.end_date).toLocaleDateString() : '—'],
              ].map(([label, value]) => (
                <div key={String(label)}>
                  <p className="text-[11px] text-dim font-bold uppercase tracking-wider mb-1">{label as string}</p>
                  <div className="text-[14px] text-white">{value as React.ReactNode}</div>
                </div>
              ))}
              {selected.terms_text && (
                <div>
                  <p className="text-[11px] text-dim font-bold uppercase tracking-wider mb-2">Terms</p>
                  <p className="text-[13px] text-muted bg-bg-2 rounded-lg p-4 leading-relaxed">{selected.terms_text}</p>
                </div>
              )}
              {selected.notes && (
                <div>
                  <p className="text-[11px] text-dim font-bold uppercase tracking-wider mb-2">Notes</p>
                  <p className="text-[13px] text-muted">{selected.notes}</p>
                </div>
              )}
            </div>
            <div className="mt-8 flex gap-3">
              {selected.status === 'pending_signature' && (
                <button className="btn-primary flex-1 justify-center">Sign Contract</button>
              )}
              {selected.status === 'draft' && (
                <button className="btn-primary flex-1 justify-center">Send for Signature</button>
              )}
              <button className="btn-ghost">Download PDF</button>
            </div>
          </div>
        </div>
      )}

      {/* New contract modal */}
      {showNew && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4">
          <div className="bg-surface border border-border rounded-2xl p-10 w-[520px] max-h-[90vh] overflow-y-auto">
            <h2 className="font-display font-extrabold text-2xl mb-1.5">New Contract</h2>
            <p className="text-muted text-[13px] mb-7">All contracts are stored securely and can be sent for e-signature.</p>

            <div className="space-y-5">
              <div>
                <label className="label">Contract Type</label>
                <div className="grid grid-cols-3 gap-2">
                  {CONTRACT_TYPES.map(t => (
                    <button key={t}
                      onClick={() => setForm(f => ({ ...f, contract_type: t }))}
                      className={`py-2 px-3 rounded-lg border text-xs font-semibold transition-all capitalize
                        ${form.contract_type === t ? 'border-gold bg-gold/10 text-gold' : 'border-border text-muted hover:border-border-2'}`}>
                      {t.replace('_', ' ')}
                    </button>
                  ))}
                </div>
              </div>
              {[
                { label: 'Contract Title *', key: 'title', placeholder: 'e.g. Sauti za Busara Festival' },
                { label: 'Counterparty *', key: 'counterparty', placeholder: 'e.g. Sauti za Busara Foundation' },
                { label: 'Counterparty Email', key: 'counterparty_email', placeholder: 'contact@example.com' },
                { label: 'Value (USD)', key: 'value_usd', placeholder: '0.00' },
              ].map(field => (
                <div key={field.key}>
                  <label className="label">{field.label}</label>
                  <input className="input" type={field.key === 'value_usd' ? 'number' : 'text'} placeholder={field.placeholder}
                    value={(form as any)[field.key]} onChange={e => setForm(f => ({ ...f, [field.key]: e.target.value }))} />
                </div>
              ))}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="label">Start Date</label>
                  <input className="input" type="date" value={form.start_date} onChange={e => setForm(f => ({ ...f, start_date: e.target.value }))} />
                </div>
                <div>
                  <label className="label">End Date</label>
                  <input className="input" type="date" value={form.end_date} onChange={e => setForm(f => ({ ...f, end_date: e.target.value }))} />
                </div>
              </div>
              <div>
                <label className="label">Notes</label>
                <textarea className="input resize-none" rows={3} placeholder="Any notes or special terms..."
                  value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
              </div>
            </div>

            <div className="flex gap-3 mt-8">
              <button className="btn-primary flex-1 justify-center py-3" onClick={handleCreate}>Create Contract</button>
              <button className="btn-ghost py-3 px-6" onClick={() => setShowNew(false)}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
