/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './app/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      fontFamily: {
        display: ['var(--font-syne)', 'sans-serif'],
        body: ['var(--font-dm-sans)', 'sans-serif'],
        mono: ['var(--font-dm-mono)', 'monospace'],
      },
      colors: {
        bg: { DEFAULT: '#080a0c', 2: '#0f1215' },
        surface: { DEFAULT: '#141820', 2: '#1c2230' },
        border: { DEFAULT: '#232b38', 2: '#2e3a4e' },
        gold: { DEFAULT: '#e8a030', light: '#f5c060' },
        teal: { DEFAULT: '#00c8a0', light: '#00f0c0' },
        danger: '#e05545',
        muted: '#9aa8be',
        dim: '#5a6880',
      },
      backgroundImage: {
        'gold-gradient': 'linear-gradient(135deg, #e8a030 0%, #f5c060 100%)',
        'teal-gradient': 'linear-gradient(135deg, #00c8a0 0%, #00f0c0 100%)',
      }
    },
  },
  plugins: [],
}
