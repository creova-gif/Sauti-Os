/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    serverActions: { allowedOrigins: ['localhost:3000'] }
  },
  images: {
    remotePatterns: [
      { protocol: 'https', hostname: 'ecuafonnvppsblxitgcu.supabase.co' }
    ]
  }
}

module.exports = nextConfig
